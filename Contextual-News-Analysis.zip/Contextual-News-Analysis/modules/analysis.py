from networkx.algorithms import community, centrality

def analyze_graph(G):
    # Error handling for empty graphs
    try:
        centrality_scores = centrality.degree_centrality(G)
    except Exception:
        centrality_scores = {}

    try:
        communities = list(community.louvain_communities(G))
    except Exception:
        communities = []

    return {
        "centrality": centrality_scores,  # Key name must match exactly
        "communities": communities
    }