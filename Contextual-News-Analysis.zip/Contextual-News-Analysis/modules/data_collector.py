import feedparser
from retry import retry

@retry(tries=3, delay=2)
def fetch_articles():
    articles = []
    with open("rss_feeds.txt") as f:
        for url in f.read().splitlines():
            feed = feedparser.parse(url)
            for entry in feed.entries[:3]:  # First 3 articles per feed
                articles.append({
                    "title": entry.title,
                    "summary": entry.description,
                    "link": entry.link,
                    "date": entry.published
                })
    return articles