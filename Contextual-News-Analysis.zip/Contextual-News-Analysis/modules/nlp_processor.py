import spacy
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# Load transformer-based model
nlp = spacy.load("en_core_web_trf")
sentiment_analyzer = SentimentIntensityAnalyzer()

def analyze(text):
    doc = nlp(text)
    sentiment = sentiment_analyzer.polarity_scores(text)
    
    return {
        "entities": [(ent.text, ent.label_) for ent in doc.ents],
        "sentiment": "neg" if sentiment["compound"] < -0.05 else "pos",
        "sentiment_score": sentiment["compound"]
    }