from pyvis.network import Network

def create_visualization(G, analysis):
    net = Network(height="750px", width="100%", notebook=False)
    
    # Safely get centrality scores with fallback
    centrality = analysis.get('centrality', {})
    
    for node in G.nodes():
        net.add_node(node,
            label=node,
            color="#ff6666" if G.nodes[node].get('sentiment') == 'neg' else "#66b3ff",
            size=10 + 30 * centrality.get(node, 0)  # Double safety
        )
    
    for edge in G.edges():
        net.add_edge(edge[0], edge[1])
    
    net.save_graph("risk_network.html")