import networkx as nx

def build_graph(articles):
    G = nx.Graph()
    
    for article in articles:
        # Add article node with metadata
        G.add_node(article['title'], 
            type='article',
            date=article['date'],
            sentiment=article['sentiment'],
            source=article['link']
        )
        
        # Add entity nodes and relationships
        for entity, label in article['entities']:
            G.add_node(entity,
                type=label,
                sentiment=article['sentiment']
            )
            G.add_edge(article['title'], entity,
                relationship=f"MENTIONS_IN_{article['sentiment'].upper()}_CONTEXT",
                source=article['link']
            )
    
    return G