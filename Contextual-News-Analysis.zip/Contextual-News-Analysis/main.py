from modules.data_collector import fetch_articles
from modules.nlp_processor import analyze
from modules.graph_builder import build_graph
from modules.analysis import analyze_graph
from modules.visualizer import create_visualization

def main():
    print("Starting enhanced risk analysis pipeline...")
    
    # Step 1: Data Collection
    print("Fetching articles from RSS feeds...")
    articles = fetch_articles()
    
    # Step 2: NLP Processing
    print("Performing deep NLP analysis...")
    for article in articles:
        analysis = analyze(article["summary"])
        article.update(analysis)
    
    # Step 3: Graph Construction
    print("Building enhanced knowledge graph...")
    G = build_graph(articles)
    
    # Step 4: Advanced Analysis
    print("Running graph analytics...")
    analysis_results = analyze_graph(G)
    
    # Step 5: Visualization
    print("Generating professional visualization...")
    create_visualization(G, analysis_results)
    
    print("Pipeline complete! Open risk_network.html")

if __name__ == "__main__":
    main()